#! /bin/bash
rm /etc/squid/squid.conf*
