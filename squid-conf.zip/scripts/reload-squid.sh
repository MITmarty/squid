#! /bin/bash
service squid reload
